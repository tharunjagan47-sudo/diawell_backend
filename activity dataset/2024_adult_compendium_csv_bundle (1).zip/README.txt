2024 Adult Compendium of Physical Activities - CSV conversion

Full extracted dataset: 1097 activity rows.
Walking/Running/Bicycling subset: 203 activity rows.

Columns: activity_category, activity_code, met_value, activity_description.
Source PDF: 2024 Adult Compendium of Physical Activities (provided by user).

Important: MET values are reference estimates for activity energy expenditure. This dataset does not contain glucose readings or personalized exercise prescriptions. Do not use MET values alone to infer a safe duration/distance for a specific person. For DiaWell, combine activity reference data with user context and validated safety rules; glucose alone should not determine exercise prescription.
